module.exports = require('prettier-config-nk');
